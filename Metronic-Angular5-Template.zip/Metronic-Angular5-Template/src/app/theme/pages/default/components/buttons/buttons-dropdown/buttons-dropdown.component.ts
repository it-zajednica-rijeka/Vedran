import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
    selector: "app-buttons-dropdown",
    templateUrl: "./buttons-dropdown.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class ButtonsDropdownComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}