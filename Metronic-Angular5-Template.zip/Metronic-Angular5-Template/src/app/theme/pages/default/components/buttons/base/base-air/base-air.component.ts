import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
    selector: "app-base-air",
    templateUrl: "./base-air.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class BaseAirComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}