import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
    selector: "app-controls-switch",
    templateUrl: "./controls-switch.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class ControlsSwitchComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}