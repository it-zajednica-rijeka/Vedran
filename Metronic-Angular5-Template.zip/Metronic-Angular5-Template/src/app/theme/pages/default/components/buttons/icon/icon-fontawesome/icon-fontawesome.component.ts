import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
    selector: "app-icon-fontawesome",
    templateUrl: "./icon-fontawesome.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class IconFontawesomeComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}