import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
    selector: "app-base-accordions",
    templateUrl: "./base-accordions.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class BaseAccordionsComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}