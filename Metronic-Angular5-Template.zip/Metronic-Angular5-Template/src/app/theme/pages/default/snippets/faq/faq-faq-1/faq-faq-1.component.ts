import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
    selector: "app-faq-faq-1",
    templateUrl: "./faq-faq-1.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class FaqFaq1Component implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}